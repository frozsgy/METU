<h1>CENG140 - Take Home Exam 2 Tester</h1>
<h2>How to Use?</h2>
<p>Place your homework submission in the main directory with the name: <i>the2.c</i> and run <i>tester.py</i> under your favourite Linux environment.</p>
<p>PS: You must have at least one I/O pair for the part of the homework you'd like to run, otherwise the program won't work.</p>
<h2>Current I/O Pairs List</h2>
<ul>
<li>Sample_1 - Provided by the instructors</li>
<li>Sample_2 - Provided by the instructors</li>
<li>The-X-Files - Courtesy of M. Ozan Alpay</li>
<li>Star_GORA - Courtesy of M. Ozan Alpay</li>
<li>ac1 ... ac7 - Courtesy of Alperen Caykus</li>

</ul>
<h2>Can I add my own tests?</h2>
<p><b>Yes, you can.</b></p>
<p>Place your I/O pair inside the tests folder as the following naming: name.in name.out and voila!</p>
<p>Cheers and enjoy the ride!</p>
<h5>Developed by <i>Alperen Caykus & Mustafa Ozan Alpay</i></h6>

package ceng.ceng351.labdb;



public class LabDB {



    public LabDB(int bucketSize) {
        
    }

    public void enter(String studentID) {
        
    }

    public void leave(String studentID) {
        
    }

    public String search(String studentID) {
        return "";
    }

    public void printLab() {
        
    }
}

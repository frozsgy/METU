package ceng.ceng351.labdb;


public class Evaluate5 {

    public static void main(String[] args) {
        LabDB labdb = new LabDB(2);
        for (int i = 1; i <= 10; i++) 
        {
            labdb.enter("e" + Integer.toString((int)Math.pow(2, i)));
        }
        labdb.printLab();
    }

}




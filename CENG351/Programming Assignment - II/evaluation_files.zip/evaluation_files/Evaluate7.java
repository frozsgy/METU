package ceng.ceng351.labdb;


public class Evaluate7 {

    public static void main(String[] args) {
        LabDB labdb = new LabDB(4);
        
        for (int i = 1; i <= 10; i++) 
        {
            labdb.enter("e" + Integer.toString((int)Math.pow(2, i)));
        }
        
        
        labdb.leave("e1024");
        labdb.leave("e512");
        labdb.leave("e256");
        labdb.leave("e128");
        labdb.leave("e64");
        labdb.leave("e32");
        labdb.printLab();

    }

}




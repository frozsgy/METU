package ceng.ceng351.labdb;

public class Evaluate1 {

    public static void main(String[] args) {
        LabDB labdb = new LabDB(1);
        for (int i = 0; i <= 7; i++) 
            labdb.enter("e" + Integer.toString(i));
        labdb.printLab();
    }

}




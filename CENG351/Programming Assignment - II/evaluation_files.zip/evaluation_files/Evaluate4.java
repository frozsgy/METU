package ceng.ceng351.labdb;

public class Evaluate4 {

    public static void main(String[] args) {
        LabDB labdb = new LabDB(3);
        for (int i = 0; i <= 10; i++) 
            labdb.enter("e" + Integer.toString(i));
        
        labdb.printLab();

    }

}




package ceng.ceng351.labdb;


public class Evaluate6 {

    public static void main(String[] args) {
        LabDB labdb = new LabDB(4);
     
        
        for (int i = 1; i <= 10; i++) 
        {
            labdb.enter("e" + Integer.toString(i));
        }
        labdb.leave("e10");
        labdb.printLab();

    }

}




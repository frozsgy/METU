package ceng.ceng351.labdb;

public class Evaluate8 {

    public static void main(String[] args) {
        LabDB labdb = new LabDB(2);
        for (int i = 1; i <= 10; i++) {
            labdb.enter("e" + Integer.toString((int) Math.pow(2, i)));
        }
        for (int i = 3; i <= 10; i++) {
            labdb.enter("e" + Integer.toString(i));
        }

        for (int i = 1; i <= 10; i++) {
            labdb.leave("e" + Integer.toString((int) Math.pow(2, i)));
        }
        for (int i = 3; i <= 10; i++) {
            labdb.leave("e" + Integer.toString(i));
        }

        labdb.printLab();

    }

}


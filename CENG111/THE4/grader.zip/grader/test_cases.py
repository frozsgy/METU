case1 = (['Ben Solo', 20],1)

case2 = (['Ben Solo', 20, ['Jack', 9], ['John', 18]], 1)

case3 = (['Ben Solo', 20, ['Jack', 9], ['John', 18]], 2)

case4 = (['Ben Solo', 20, ['Jack', 9, ['Nico', 14]], ['John', 18]], 2)

case5 = (['Ben Solo', 20, ['Jack', 9], ['John', 18, ['Nico', 14]]], 2)

case6 = (['Ben Solo', 20, ['Jack', 6, ['John', 2, ['Fredo', 2, ['Luke', 2], ['Vincenzo', 2]]]]], 2)

case7 = (['Ben Solo', 20, ['Jack', 6, ['John', 2, ['Fredo', 2, ['Luke', 2], ['Vincenzo', 2]]]]], 3)

case8 = (['Ben Solo', 20, ['Jack', 6, ['John', 2, ['Fredo', 2, ['Luke', 2], ['Vincenzo', 2],['Kyle', 8]]]]], 2) 

case9 = (['Ben Solo', 20, ['Jack', 6, ['John', 2, ['Fredo', 2, ['Luke', 2], ['Vincenzo', 2],['Kyle', 8]]]]], 3)

case10 = (['Ben Solo', 20, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14]]], 2)

case11 = (['Ben Solo', 20, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14]]], 3)

case12 = (['Ben Solo', 20, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14]]], 4)

case13 = (['Ben Solo', 20, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 3]]]], 1)

case14 = (['Ben Solo', 20, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 3]]]], 2)

case15 = (['Ben Solo', 20, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 3]]]], 3)

case16 = (['Ben Solo', 20, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 3]]]], 4)

case17 = (['Ben Solo', 50, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 10, ['George', 11]]]]], 3)

case18 = (['Ben Solo', 50, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 10, ['George', 11]]]]], 4)

case19 = (['Ben Solo', 50, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 10, ['George', 11, ['Jerry', 2]]]]]], 2)

case20 = (['Ben Solo', 50, ['Jack', 9, ['Fredo', 2, ['Kyle', 1], ['Luke', 1]], ['Vincenzo', 1], ['Fred', 6, ['Ela', 3], ['Han', 3]]], ['John', 18, ['Rocco', 1], ['Nico', 14, ['James', 10, ['George', 11, ['Jerry', 2]]]]]], 4)

test_cases = [case1, case2, case3, case4, case5, case6, case7, case8, case9, case10, case11, case12, case13, case14, case15, case16, case17, case18, case19, case20]

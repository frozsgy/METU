package project.parts;

public class Arm extends Part
{

}
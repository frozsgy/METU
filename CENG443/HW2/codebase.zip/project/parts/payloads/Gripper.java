package project.parts.payloads;

public class Gripper extends Payload
{

}
package project.parts.payloads;

public class Welder extends Payload
{

}
package project.parts.payloads;

public class MaintenanceKit extends Payload
{

}
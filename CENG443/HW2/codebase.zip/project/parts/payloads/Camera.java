package project.parts.payloads;

public class Camera extends Payload
{

}
package project.parts.payloads;

import project.parts.Part;

public abstract class Payload extends Part
{

}
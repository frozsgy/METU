package project.utility;

public class SmartFactoryException extends RuntimeException
{
    public SmartFactoryException ( String message )
    {
        super( message ) ;
    }
}
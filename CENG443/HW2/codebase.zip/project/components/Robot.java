package project.components;

import project.utility.Drawable;

public interface Robot extends Runnable , Drawable
{

}